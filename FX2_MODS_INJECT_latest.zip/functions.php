<?php
require_once __DIR__ . '/db.php';
function h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function csrf(): string { if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function check_csrf(): void {
  if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { http_response_code(419); exit('انتهت صلاحية الطلب. حدّث الصفحة وحاول مجدداً.'); }
}
function user(): ?array { return $_SESSION['user'] ?? null; }
function require_role(string $role): void {
  if (!user() || user()['role'] !== $role) { header('Location: /' . $role . '/'); exit; }
}
function duration_options(): array {
 return [3600=>'1 ساعة',10800=>'3 ساعات',18000=>'5 ساعات',54000=>'15 ساعة',86400=>'24 ساعة',259200=>'3 أيام',604800=>'7 أيام',1296000=>'15 يوم',2592000=>'30 يوم'];
}
function make_key(): string {
 $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; $parts=[];
 for($p=0;$p<3;$p++){ $s=''; for($i=0;$i<4;$i++) $s.=$alphabet[random_int(0,strlen($alphabet)-1)]; $parts[]=$s; }
 return 'FX2-' . implode('-', $parts);
}
function setting(PDO $pdo, string $key, string $default=''): string {
 $q=$pdo->prepare('SELECT value FROM settings WHERE name=?'); $q->execute([$key]); $v=$q->fetchColumn(); return $v===false?$default:(string)$v;
}
function page_start(string $title): void {
 echo '<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.h($title).'</title><link rel="stylesheet" href="/assets/style.css"><body><main class="wrap">';
}
function page_end(): void { echo '</main></body></html>'; }
