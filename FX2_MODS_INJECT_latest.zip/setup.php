<?php
require_once __DIR__.'/db.php';
$schema = file_get_contents(__DIR__.'/install.sql');
try {
 foreach (array_filter(array_map('trim', explode(';', $schema))) as $sql) $pdo->exec($sql);
 $count=(int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn();
 if ($count===0 && $_SERVER['REQUEST_METHOD']==='POST') {
   $u=trim($_POST['username']??''); $p=$_POST['password']??'';
   if (strlen($u)<3 || strlen($p)<10) $error='اسم المستخدم 3 أحرف على الأقل وكلمة المرور 10 أحرف على الأقل.';
   else { $q=$pdo->prepare("INSERT INTO users(username,password_hash,role) VALUES(?,?, 'admin')");
     $q->execute([$u,password_hash($p,PASSWORD_DEFAULT)]); $done=true; }
 }
} catch(Throwable $e) { $error='فشل إنشاء الجداول. تأكد من صلاحيات قاعدة البيانات.'; }
require_once __DIR__.'/functions.php';
page_start('إعداد FX2 MODS');
echo '<section class="panel"><h1>إعداد FX2 MODS</h1>';
if(!empty($done)) echo '<p class="success">تم إنشاء حساب المدير. احذف setup.php الآن ثم ادخل إلى /admin/</p>';
elseif($count===0) {
 if(!empty($error)) echo '<p class="error">'.h($error).'</p>';
 echo '<form method="post"><label>اسم المدير</label><input name="username" required minlength="3"><label>كلمة مرور قوية</label><input type="password" name="password" required minlength="10"><button>إنشاء المدير</button></form>';
} else echo '<p>تم إعداد الموقع مسبقاً. احذف setup.php لأسباب أمنية.</p>';
echo '</section>'; page_end();
