<?php
require_once __DIR__.'/../auth.php';
if(!user() && authenticate('admin')) { header('Location: /admin/'); exit; }
if(!user()) { login_form('admin'); exit; }
require_role('admin'); require __DIR__.'/../dashboard.php';
