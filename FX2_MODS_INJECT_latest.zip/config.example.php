<?php
// انسخ هذا الملف إلى config.php ثم أدخل بيانات MySQL من لوحة الاستضافة.
return [
  'db_host' => 'localhost',
  'db_name' => 'YOUR_DATABASE',
  'db_user' => 'YOUR_DB_USER',
  'db_pass' => 'YOUR_DB_PASSWORD',
  'app_name' => 'FX2 MODS',
  'timezone' => 'Africa/Casablanca',
];
