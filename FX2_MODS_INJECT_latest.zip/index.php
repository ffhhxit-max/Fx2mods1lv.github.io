<?php
require_once __DIR__.'/functions.php';
$maintenance=setting($pdo,'maintenance','0')==='1';
$download=setting($pdo,'ios_download_url','');
$channel=setting($pdo,'whatsapp_channel','');
$msg=''; $active=null;
if($_SERVER['REQUEST_METHOD']==='POST'){
 check_csrf();
 $key=strtoupper(trim($_POST['code']??''));
 $q=$pdo->prepare("SELECT * FROM codes WHERE code=?"); $q->execute([$key]); $c=$q->fetch();
 if(!$c) $msg='الكود غير صحيح.';
 elseif($c['status']==='disabled') $msg='هذا الكود متوقف. تواصل مع الإدارة.';
 else {
   if(!$c['activated_at'] && $c['status']==='unused'){
     $now=new DateTimeImmutable(); $end=$now->modify('+'.$c['duration_seconds'].' seconds');
     $u=$pdo->prepare("UPDATE codes SET activated_at=?,expires_at=?,status='active' WHERE id=?");
     $u->execute([$now->format('Y-m-d H:i:s'),$end->format('Y-m-d H:i:s'),$c['id']]);
     $c['activated_at']=$now->format('Y-m-d H:i:s'); $c['expires_at']=$end->format('Y-m-d H:i:s'); $c['status']='active';
   }
   if(strtotime($c['expires_at']??'')<=time()){ $pdo->prepare("UPDATE codes SET status='expired' WHERE id=?")->execute([$c['id']]); $msg='انتهت صلاحية هذا الكود.'; }
   else $active=$c;
 }
}
page_start('FX2 MODS CLIENT');
echo '<header class="top"><b>FX2 MODS</b><span class="pill">CLIENT</span></header>';
if($maintenance) echo '<section class="panel"><h1>الموقع في الصيانة</h1><p>حاول مرة أخرى لاحقاً.</p></section>';
else {
 echo '<section class="panel hero"><img class="brand-logo" src="/assets/fx2-logo.jpg" alt="FX2 MODS"><h1>FX2 MODS <em>CLIENT</em></h1><p>لا تحتاج إلى حساب، فقط مفتاحك.</p>';
 if($msg) echo '<p class="error">'.h($msg).'</p>';
 if($active){
   $left=max(0,strtotime($active['expires_at'])-time());
   echo '<h2>اشتراكك مفعل</h2><div class="timer" data-seconds="'.$left.'">'.gmdate('H:i:s',$left).'</div><p>ينتهي: '.h($active['expires_at']).'</p>';
 } else {
   echo '<form method="post"><input type="hidden" name="csrf" value="'.h(csrf()).'"><label>مفتاح الدخول</label><input name="code" placeholder="FX2-XXXX-XXXX-XXXX" required><button>تفعيل الاشتراك</button></form>';
 }
 if($download) echo '<a class="button secondary" href="'.h($download).'" target="_blank" rel="noopener">تنزيل تطبيق VPN للآيفون</a>';
 else echo '<p class="muted">رابط تنزيل تطبيق iOS سيظهر هنا بعد إضافته من لوحة الإدارة.</p>';
 $happ=setting($pdo,'happ_server_link','');
 if($happ) echo '<a class="button secondary" href="'.h($happ).'">استيراد إعدادات HAPP</a>';
 $servers=$pdo->query('SELECT id,name,server_url,description FROM servers WHERE enabled=1 ORDER BY id DESC')->fetchAll();
 if($servers){
   echo '<h2 class="server-heading">VPN SERVERS</h2><div class="server-grid">';
   foreach($servers as $sv){
     echo '<article class="server-card"><b>'.h($sv['name']).'</b><p>'.h($sv['description']).'</p><a class="button inject" href="'.h($sv['server_url']).'">INJECT</a></article>';
   }
   echo '</div>';
 }
 if($channel) echo '<a class="button green" href="'.h($channel).'" target="_blank" rel="noopener">قناة واتساب الرسمية</a>';
 echo '</section>';
}
echo '<footer>FX2 MODS · Client</footer><script>document.querySelectorAll(".timer").forEach(el=>{let n=Number(el.dataset.seconds||0);const tick=()=>{if(n<0)n=0;const h=String(Math.floor(n/3600)).padStart(2,"0"),m=String(Math.floor(n%3600/60)).padStart(2,"0"),s=String(n%60).padStart(2,"0");el.textContent=h+":"+m+":"+s;if(n>0)n--;};tick();setInterval(tick,1000);});</script>';
page_end();
