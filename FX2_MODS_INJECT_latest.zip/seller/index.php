<?php
require_once __DIR__.'/../auth.php';
if(!user() && authenticate('seller')) { header('Location: /seller/'); exit; }
if(!user()) { login_form('seller'); exit; }
require_role('seller'); require __DIR__.'/../dashboard.php';
