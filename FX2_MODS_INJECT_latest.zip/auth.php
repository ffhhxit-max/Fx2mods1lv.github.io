<?php
require_once __DIR__.'/functions.php';
function login_form(string $role): void {
 page_start('تسجيل الدخول');
 echo '<section class="panel narrow"><h1>FX2 MODS</h1><h2>دخول '.($role==='admin'?'المدير':'البائع').'</h2>';
 if(!empty($_SESSION['login_error'])) { echo '<p class="error">'.h($_SESSION['login_error']).'</p>'; unset($_SESSION['login_error']); }
 echo '<form method="post"><input type="hidden" name="csrf" value="'.h(csrf()).'"><label>اسم المستخدم</label><input name="username" required><label>كلمة المرور</label><input type="password" name="password" required><button>دخول</button></form></section>'; page_end();
}
function authenticate(string $role): bool {
 if($_SERVER['REQUEST_METHOD']!=='POST') return false;
 check_csrf(); $q=$GLOBALS['pdo']->prepare('SELECT * FROM users WHERE username=? AND role=?'); $q->execute([trim($_POST['username']??''),$role]); $u=$q->fetch();
 if($u && password_verify($_POST['password']??'', $u['password_hash'])) {
   session_regenerate_id(true); $_SESSION['user']=['id'=>$u['id'],'username'=>$u['username'],'role'=>$u['role']]; return true;
 }
 $_SESSION['login_error']='بيانات الدخول غير صحيحة.'; return false;
}
