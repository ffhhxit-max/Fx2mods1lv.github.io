<?php
declare(strict_types=1);
$configFile = __DIR__ . '/config.php';
if (!file_exists($configFile)) { http_response_code(500); exit('أعد تسمية config.example.php إلى config.php وأدخل بيانات قاعدة البيانات.'); }
$config = require $configFile;
date_default_timezone_set($config['timezone'] ?? 'Africa/Casablanca');
try {
  $pdo = new PDO(
    "mysql:host={$config['db_host']};dbname={$config['db_name']};charset=utf8mb4",
    $config['db_user'], $config['db_pass'],
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
  );
} catch (Throwable $e) { http_response_code(500); exit('تعذر الاتصال بقاعدة البيانات. راجع إعدادات config.php.'); }
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
