<?php
require_once __DIR__.'/functions.php';
$me=user(); $isAdmin=$me['role']==='admin';
$msg=''; $error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 check_csrf(); $action=$_POST['action']??'';
 if($action==='generate'){
   $seconds=(int)($_POST['duration']??0); $qty=max(1,min(100,(int)($_POST['qty']??1)));
   $allowed=duration_options();
   if(!isset($allowed[$seconds])) $error='اختر مدة صحيحة.';
   else {
     $ins=$pdo->prepare('INSERT INTO codes(code,duration_seconds,created_by) VALUES(?,?,?)');
     for($i=0;$i<$qty;$i++){ do{$code=make_key();$q=$pdo->prepare('SELECT id FROM codes WHERE code=?');$q->execute([$code]);}while($q->fetch()); $ins->execute([$code,$seconds,$me['id']]); }
     $msg="تم إنشاء $qty كود بنجاح.";
   }
 }
 if($action==='maintenance' && $isAdmin){ $v=($_POST['value']??'0')==='1'?'1':'0'; $pdo->prepare("UPDATE settings SET value=? WHERE name='maintenance'")->execute([$v]); $msg='تم تحديث وضع الصيانة.'; }
 if($action==='download' && $isAdmin){ $v=trim($_POST['url']??''); if($v!=='' && !filter_var($v,FILTER_VALIDATE_URL)) $error='رابط التنزيل غير صحيح.'; else { $pdo->prepare("UPDATE settings SET value=? WHERE name='ios_download_url'")->execute([$v]); $msg='تم حفظ رابط التنزيل.'; } }
 if($action==='happ_server' && $isAdmin){
   $v=trim($_POST['url']??'');
   if($v!=='' && !str_starts_with($v,'happ://crypt5/')) $error='رابط HAPP غير صالح؛ يجب أن يبدأ بـ happ://crypt5/';
   else { $q=$pdo->prepare("INSERT INTO settings(name,value) VALUES('happ_server_link',?) ON DUPLICATE KEY UPDATE value=VALUES(value)"); $q->execute([$v]); $msg='تم حفظ رابط سيرفر HAPP.'; }
 }
 if($action==='server_add' && $isAdmin){
   $name=trim($_POST['name']??''); $url=trim($_POST['server_url']??''); $desc=trim($_POST['description']??'');
   if($name==='' || !preg_match('/^happ:\/\/crypt5\//i',$url)) $error='أدخل اسماً ورابط HAPP يبدأ بـ happ://crypt5/';
   else { $q=$pdo->prepare('INSERT INTO servers(name,server_url,description,enabled) VALUES(?,?,?,1)'); $q->execute([$name,$url,$desc]); $msg='تمت إضافة السيرفر.'; }
 }
 if($action==='server_toggle' && $isAdmin){ $pdo->prepare('UPDATE servers SET enabled=IF(enabled=1,0,1) WHERE id=?')->execute([(int)($_POST['id']??0)]); $msg='تم تحديث حالة السيرفر.'; }
 if($action==='server_delete' && $isAdmin){ $pdo->prepare('DELETE FROM servers WHERE id=?')->execute([(int)($_POST['id']??0)]); $msg='تم حذف السيرفر.'; }
 if($action==='seller' && $isAdmin){
   $u=trim($_POST['username']??''); $p=$_POST['password']??'';
   if(strlen($u)<3||strlen($p)<10) $error='اسم المستخدم 3 أحرف وكلمة المرور 10 أحرف على الأقل.';
   else { try{$q=$pdo->prepare("INSERT INTO users(username,password_hash,role) VALUES(?,?,'seller')");$q->execute([$u,password_hash($p,PASSWORD_DEFAULT)]);$msg='تم إنشاء حساب البائع.';}catch(Throwable $e){$error='اسم المستخدم مستعمل بالفعل.';} }
 }
 if($action==='disable' && $isAdmin){$pdo->prepare("UPDATE codes SET status='disabled' WHERE id=?")->execute([(int)$_POST['id']]);$msg='تم إيقاف الكود.';}
}
$ownSql=$isAdmin?'':' WHERE created_by='.((int)$me['id']);
$codes=$pdo->query('SELECT c.*,u.username AS seller FROM codes c JOIN users u ON u.id=c.created_by'.$ownSql.' ORDER BY c.id DESC LIMIT 250')->fetchAll();
page_start('لوحة '.($isAdmin?'المدير':'البائع'));
echo '<header class="top"><b>FX2 MODS · '.($isAdmin?'ADMIN':'SELLER').'</b><a href="/logout.php">خروج</a></header>';
if($msg)echo '<p class="success">'.h($msg).'</p>'; if($error)echo '<p class="error">'.h($error).'</p>';
echo '<section class="panel"><h2>توليد الكودات</h2><form method="post"><input type="hidden" name="csrf" value="'.h(csrf()).'"><input type="hidden" name="action" value="generate"><label>مدة الاشتراك</label><select name="duration">';
foreach(duration_options() as $s=>$label)echo '<option value="'.$s.'">'.h($label).'</option>';
echo '</select><label>عدد الكودات (1 إلى 100)</label><input type="number" name="qty" min="1" max="100" value="1"><button>توليد كود FX2-</button></form></section>';
if($isAdmin){
 echo '<section class="panel"><h2>إدارة الموقع</h2><form method="post"><input type="hidden" name="csrf" value="'.h(csrf()).'"><input type="hidden" name="action" value="maintenance"><input type="hidden" name="value" value="'.(setting($pdo,'maintenance','0')==='1'?'0':'1').'"><button class="secondary">'.(setting($pdo,'maintenance','0')==='1'?'إيقاف الصيانة':'تفعيل الصيانة').'</button></form>';
 echo '<form method="post"><input type="hidden" name="csrf" value="'.h(csrf()).'"><input type="hidden" name="action" value="download"><label>رابط تطبيق VPN للآيفون (IPA أو صفحة تثبيت موثوقة)</label><input name="url" value="'.h(setting($pdo,'ios_download_url')).'" placeholder="https://..."><button>حفظ الرابط</button></form><form method="post"><input type="hidden" name="csrf" value="'.h(csrf()).'"><input type="hidden" name="action" value="happ_server"><label>رابط سيرفر HAPP المشفر</label><textarea name="url" rows="4" placeholder="happ://crypt5/...">'.h(setting($pdo,'happ_server_link')).'</textarea><button>حفظ سيرفر HAPP</button></form></section>';
 echo '<section class="panel"><h2>إدارة روابط السيرفرات</h2><form method="post"><input type="hidden" name="csrf" value="'.h(csrf()).'"><input type="hidden" name="action" value="server_add"><label>اسم السيرفر</label><input name="name" placeholder="مثال: HAPP Server 1" required><label>رابط HAPP المشفر</label><textarea name="server_url" rows="4" placeholder="happ://crypt5/..." required></textarea><label>وصف (اختياري)</label><input name="description" placeholder="الدولة أو ملاحظات"><button>إضافة السيرفر</button></form>';
 $serversAdmin=$pdo->query('SELECT * FROM servers ORDER BY id DESC')->fetchAll();
 foreach($serversAdmin as $sv){ echo '<div class="server-row"><div><b>'.h($sv['name']).'</b><p class="muted">'.h($sv['description']).' · '.($sv['enabled']?'مفعل':'متوقف').'</p></div><div class="server-actions"><form method="post"><input type="hidden" name="csrf" value="'.h(csrf()).'"><input type="hidden" name="action" value="server_toggle"><input type="hidden" name="id" value="'.(int)$sv['id'].'"><button class="secondary small">'.($sv['enabled']?'إيقاف':'تفعيل').'</button></form><form method="post" onsubmit="return confirm(\'حذف السيرفر؟\')"><input type="hidden" name="csrf" value="'.h(csrf()).'"><input type="hidden" name="action" value="server_delete"><input type="hidden" name="id" value="'.(int)$sv['id'].'"><button class="danger small">حذف</button></form></div></div>'; }
 echo '</section>';
 echo '<section class="panel"><h2>إنشاء حساب بائع</h2><form method="post"><input type="hidden" name="csrf" value="'.h(csrf()).'"><input type="hidden" name="action" value="seller"><label>اسم المستخدم</label><input name="username" required><label>كلمة مرور قوية</label><input type="password" name="password" minlength="10" required><button>إنشاء البائع</button></form></section>';
}
echo '<section class="panel"><h2>الكودات المنشأة</h2><div class="tablewrap"><table><tr><th>الكود</th><th>المدة</th><th>الحالة</th>'.($isAdmin?'<th>البائع</th>':'').'<th>تاريخ الإنشاء</th>'.($isAdmin?'<th>إجراء</th>':'').'</tr>';
foreach($codes as $c){echo '<tr><td><code>'.h($c['code']).'</code></td><td>'.h(duration_options()[$c['duration_seconds']]??$c['duration_seconds']).'</td><td>'.h($c['status']).'</td>'.($isAdmin?'<td>'.h($c['seller']).'</td>':'').'<td>'.h($c['created_at']).'</td>'.($isAdmin?'<td><form method="post"><input type="hidden" name="csrf" value="'.h(csrf()).'"><input type="hidden" name="action" value="disable"><input type="hidden" name="id" value="'.(int)$c['id'].'"><button class="danger small">إيقاف</button></form></td>':'').'</tr>';}
echo '</table></div></section>'; page_end();
